package com.poblenou.tmb_app

data class RSSNotification(
    val title: String,
    val description: String,
    val date: String
)
