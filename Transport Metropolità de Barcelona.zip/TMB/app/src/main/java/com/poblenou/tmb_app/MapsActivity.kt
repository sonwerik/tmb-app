package com.poblenou.tmb_app

import android.os.Bundle
import androidx.fragment.app.FragmentActivity

class MapsActivity : FragmentActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.fragment_dashboard)
    }
}
